// Global Worx LLC - Main JavaScript
// Apple-inspired interactions and animations

class GlobalWorxApp {
    constructor() {
        this.isLoaded = false;
        this.init();
    }

    init() {
        document.addEventListener('DOMContentLoaded', () => {
            this.setupNavigation();
            this.setupScrollAnimations();
            this.setupHoverEffects();
            this.setupFormHandling();
            this.setupMobileMenu();
            this.initPageAnimations();
        });
    }

    setupNavigation() {
        const nav = document.querySelector('.nav-container');
        const navLinks = document.querySelectorAll('.nav-link');
        
        // Sticky navigation with background fade
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                nav.classList.add('nav-scrolled');
            } else {
                nav.classList.remove('nav-scrolled');
            }
        });

        // Active page highlighting
        const currentPage = window.location.pathname.split('/').pop() || 'index.html';
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === currentPage || (currentPage === '' && href === 'index.html')) {
                link.classList.add('nav-link-active');
            }
        });
    }

    setupScrollAnimations() {
        // Intersection Observer for scroll-triggered animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);

        // Observe all animatable elements
        document.querySelectorAll('.animate-on-scroll').forEach(el => {
            observer.observe(el);
        });
    }

    setupHoverEffects() {
        // Service cards hover effects
        const serviceCards = document.querySelectorAll('.service-card');
        serviceCards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                anime({
                    targets: card,
                    translateY: -8,
                    scale: 1.02,
                    boxShadow: '0 20px 40px rgba(0, 86, 179, 0.15)',
                    duration: 300,
                    easing: 'easeOutCubic'
                });
            });

            card.addEventListener('mouseleave', () => {
                anime({
                    targets: card,
                    translateY: 0,
                    scale: 1,
                    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)',
                    duration: 300,
                    easing: 'easeOutCubic'
                });
            });
        });

        // Button hover effects
        const buttons = document.querySelectorAll('.btn-primary, .btn-secondary');
        buttons.forEach(button => {
            button.addEventListener('mouseenter', () => {
                anime({
                    targets: button,
                    scale: 1.05,
                    duration: 200,
                    easing: 'easeOutCubic'
                });
            });

            button.addEventListener('mouseleave', () => {
                anime({
                    targets: button,
                    scale: 1,
                    duration: 200,
                    easing: 'easeOutCubic'
                });
            });
        });
    }

    setupFormHandling() {
        const contactForm = document.querySelector('#contact-form');
        if (contactForm) {
            contactForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleFormSubmission(contactForm);
            });
        }

        // Form field animations
        const formFields = document.querySelectorAll('.form-field');
        formFields.forEach(field => {
            const input = field.querySelector('input, textarea, select');
            
            input.addEventListener('focus', () => {
                field.classList.add('form-field-focused');
            });

            input.addEventListener('blur', () => {
                if (!input.value) {
                    field.classList.remove('form-field-focused');
                }
            });

            // Check for pre-filled values
            if (input.value) {
                field.classList.add('form-field-focused');
            }
        });
    }

    async handleFormSubmission(form) {
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        // Loading state
        submitBtn.textContent = 'Sending...';
        submitBtn.disabled = true;

        // Simulate form submission (replace with actual endpoint)
        try {
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Success state
            this.showFormSuccess(form);
        } catch (error) {
            // Error state
            this.showFormError(form);
        } finally {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    }

    showFormSuccess(form) {
        const successMessage = document.createElement('div');
        successMessage.className = 'form-success';
        successMessage.innerHTML = `
            <div class="success-icon">✓</div>
            <h3>Message Sent Successfully</h3>
            <p>Thank you for your inquiry. Our team will respond within 24 hours.</p>
        `;
        
        form.parentNode.appendChild(successMessage);
        form.style.display = 'none';

        // Animate success message
        anime({
            targets: successMessage,
            opacity: [0, 1],
            translateY: [20, 0],
            duration: 500,
            easing: 'easeOutCubic'
        });
    }

    showFormError(form) {
        const errorMessage = document.createElement('div');
        errorMessage.className = 'form-error';
        errorMessage.textContent = 'There was an error sending your message. Please try again.';
        
        form.appendChild(errorMessage);
        
        anime({
            targets: errorMessage,
            opacity: [0, 1],
            duration: 300
        });

        setTimeout(() => {
            errorMessage.remove();
        }, 5000);
    }

    setupMobileMenu() {
        const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
        const mobileMenu = document.querySelector('.mobile-menu');
        const mobileMenuOverlay = document.querySelector('.mobile-menu-overlay');

        if (mobileMenuBtn) {
            mobileMenuBtn.addEventListener('click', () => {
                this.toggleMobileMenu();
            });
        }

        if (mobileMenuOverlay) {
            mobileMenuOverlay.addEventListener('click', () => {
                this.closeMobileMenu();
            });
        }

        // Close mobile menu on link click
        const mobileLinks = document.querySelectorAll('.mobile-menu a');
        mobileLinks.forEach(link => {
            link.addEventListener('click', () => {
                this.closeMobileMenu();
            });
        });
    }

    toggleMobileMenu() {
        const mobileMenu = document.querySelector('.mobile-menu');
        const mobileMenuOverlay = document.querySelector('.mobile-menu-overlay');
        const isOpen = mobileMenu.classList.contains('mobile-menu-open');

        if (isOpen) {
            this.closeMobileMenu();
        } else {
            this.openMobileMenu();
        }
    }

    openMobileMenu() {
        const mobileMenu = document.querySelector('.mobile-menu');
        const mobileMenuOverlay = document.querySelector('.mobile-menu-overlay');
        
        mobileMenu.classList.add('mobile-menu-open');
        mobileMenuOverlay.classList.add('overlay-active');
        document.body.style.overflow = 'hidden';

        anime({
            targets: mobileMenu,
            translateX: [300, 0],
            duration: 300,
            easing: 'easeOutCubic'
        });

        anime({
            targets: mobileMenuOverlay,
            opacity: [0, 1],
            duration: 300
        });
    }

    closeMobileMenu() {
        const mobileMenu = document.querySelector('.mobile-menu');
        const mobileMenuOverlay = document.querySelector('.mobile-menu-overlay');
        
        anime({
            targets: mobileMenu,
            translateX: [0, 300],
            duration: 300,
            easing: 'easeInCubic',
            complete: () => {
                mobileMenu.classList.remove('mobile-menu-open');
            }
        });

        anime({
            targets: mobileMenuOverlay,
            opacity: [1, 0],
            duration: 300,
            complete: () => {
                mobileMenuOverlay.classList.remove('overlay-active');
                document.body.style.overflow = '';
            }
        });
    }

    initPageAnimations() {
        // Hero text animations
        const heroTitle = document.querySelector('.hero-title');
        const heroSubtitle = document.querySelector('.hero-subtitle');
        const heroButton = document.querySelector('.hero-cta');

        if (heroTitle) {
            // Split text for staggered animation
            const titleText = heroTitle.textContent;
            heroTitle.innerHTML = titleText.split('').map(char => 
                `<span class="char">${char === ' ' ? '&nbsp;' : char}</span>`
            ).join('');

            anime.timeline({
                easing: 'easeOutCubic'
            })
            .add({
                targets: '.hero-title .char',
                opacity: [0, 1],
                translateY: [50, 0],
                delay: anime.stagger(50)
            })
            .add({
                targets: heroSubtitle,
                opacity: [0, 1],
                translateY: [30, 0],
                duration: 800
            }, '-=400')
            .add({
                targets: heroButton,
                opacity: [0, 1],
                translateY: [20, 0],
                scale: [0.9, 1],
                duration: 600
            }, '-=200');
        }

        // Service cards stagger animation
        const serviceCards = document.querySelectorAll('.service-card');
        if (serviceCards.length > 0) {
            anime({
                targets: serviceCards,
                opacity: [0, 1],
                translateY: [40, 0],
                delay: anime.stagger(200, {start: 1000}),
                duration: 800,
                easing: 'easeOutCubic'
            });
        }

        // Stats counter animation
        const stats = document.querySelectorAll('.stat-number');
        stats.forEach(stat => {
            const target = parseInt(stat.textContent);
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        anime({
                            targets: stat,
                            innerHTML: [0, target],
                            duration: 2000,
                            easing: 'easeOutCubic',
                            round: 1
                        });
                        observer.unobserve(entry.target);
                    }
                });
            });
            observer.observe(stat);
        });
    }

    // Smooth scroll for anchor links
    smoothScrollTo(target) {
        const element = document.querySelector(target);
        if (element) {
            const offsetTop = element.offsetTop - 80; // Account for sticky nav
            
            anime({
                targets: document.documentElement,
                scrollTop: offsetTop,
                duration: 800,
                easing: 'easeInOutCubic'
            });
        }
    }
}

// Initialize the application
const globalWorxApp = new GlobalWorxApp();

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Smooth scroll for anchor links
document.addEventListener('click', (e) => {
    if (e.target.matches('a[href^="#"]')) {
        e.preventDefault();
        const target = e.target.getAttribute('href');
        globalWorxApp.smoothScrollTo(target);
    }
});

// Performance optimization
const debouncedResize = debounce(() => {
    // Handle resize events
    if (window.innerWidth > 768) {
        globalWorxApp.closeMobileMenu();
    }
}, 250);

window.addEventListener('resize', debouncedResize);