# Global Work LLC - Design Style Guide

## Design Philosophy

### Visual Language
**Premium Minimalism**: Inspired by Apple's design philosophy, emphasizing clarity, precision, and sophisticated simplicity. Every element serves a purpose, with generous white space creating breathing room and focus on content hierarchy.

### Color Palette
**Primary Colors**:
- Pure White (#ffffff) - Primary background
- Off-White (#fbfbfd) - Secondary background
- Charcoal Gray (#1d1d1f) - Primary text
- Deep Black (#000000) - Headlines and emphasis
- Trust Blue (#0056b3) - Interactive elements, links, CTAs

**Supporting Colors**:
- Light Gray (#f5f5f7) - Card backgrounds, subtle divisions
- Medium Gray (#86868b) - Secondary text, captions
- Success Green (#30d158) - Form validation, success states
- Warning Orange (#ff9f0a) - Alerts, attention states

### Typography
**Primary Font Stack**: 
-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif

**Hierarchy**:
- **Hero Headlines**: 48-72px, Bold weight, Tight line-height
- **Section Headers**: 32-40px, Semibold weight
- **Body Text**: 16-18px, Regular weight, 1.5 line-height
- **Captions**: 14px, Regular weight, Medium gray

## Visual Effects & Styling

### Used Libraries & Effects
1. **Anime.js**: Smooth element animations, staggered text reveals
2. **Splitting.js**: Advanced text effects for headlines
3. **ECharts.js**: Professional data visualizations for performance metrics
4. **Splide.js**: Smooth image carousels for case studies
5. **p5.js**: Subtle background particle effects for hero sections
6. **Pixi.js**: Advanced visual effects for interactive elements

### Animation Principles
- **Subtle Motion**: All animations enhance usability without distraction
- **Smooth Transitions**: 300-400ms duration with ease-out timing
- **Staggered Reveals**: Content appears in logical reading order
- **Hover Feedback**: Immediate visual response to user interactions

### Header Effects
**Hero Section Styling**:
- Full-viewport height with professional logistics imagery
- Gradient text overlay with subtle animation
- Smooth parallax scrolling on background images
- Animated call-to-action buttons with depth shadows

### Interactive Elements
**Button Styles**:
- Primary: Blue background, white text, rounded corners (8px)
- Secondary: Transparent background, blue border, blue text
- Hover: Subtle scale (1.02x) with enhanced shadow

**Card Interactions**:
- Clean white backgrounds with subtle shadows
- Lift effect on hover with increased shadow depth
- Smooth color transitions for service icons
- Progressive disclosure of additional information

### Background Treatments
**Consistent Theme**: Clean white/off-white backgrounds throughout
**Subtle Textures**: Minimal geometric patterns in footer areas
**Visual Hierarchy**: Strategic use of light gray sections for content grouping

### Responsive Design
**Breakpoints**:
- Mobile: 320px - 768px
- Tablet: 768px - 1024px  
- Desktop: 1024px+

**Mobile Optimizations**:
- Touch-friendly 44px minimum button sizes
- Simplified navigation with hamburger menu
- Single-column layouts with vertical flow
- Optimized typography scaling

## Professional Services Aesthetic

### Imagery Style
**Hero Images**: High-resolution container ships, modern ports, global logistics
**Professional Photography**: Clean, well-lit office environments, diverse teams
**Icon System**: Minimalist line icons with consistent stroke weight
**Data Visualizations**: Clean charts with blue accent colors

### Content Presentation
**Trust Indicators**: Client logos, certifications, performance metrics
**Case Studies**: Clean layouts with before/after comparisons
**Team Profiles**: Professional headshots with consistent styling
**Contact Forms**: Minimalist design with floating labels

### Accessibility Standards
**Color Contrast**: Minimum 4.5:1 ratio for all text
**Focus Indicators**: Clear visual feedback for keyboard navigation
**Screen Reader Support**: Proper ARIA labels and semantic HTML
**Motion Preferences**: Respect for reduced motion settings