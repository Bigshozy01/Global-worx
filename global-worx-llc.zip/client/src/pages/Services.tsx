import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, CheckCircle, Users, Globe, Package, ClipboardCheck, TrendingUp, MapPin } from "lucide-react";

export default function Services() {
  const serviceDetails = [
    {
      id: "supply-chain",
      icon: Shield,
      title: "Supply Chain Assurance",
      image: "/images/hero-port.jpg",
      description:
        "Our supply chain assurance services provide comprehensive oversight and verification of global supply chains, ensuring compliance, integrity, and transparency at every stage of the process.",
      features: [
        {
          icon: Package,
          title: "End-to-End Monitoring",
          description: "Complete visibility across your entire supply chain from origin to destination.",
        },
        {
          icon: ClipboardCheck,
          title: "Compliance Verification",
          description: "Rigorous verification of regulatory compliance and contractual obligations.",
        },
        {
          icon: Shield,
          title: "Risk Mitigation",
          description: "Proactive identification and mitigation of supply chain vulnerabilities.",
        },
      ],
    },
    {
      id: "quality",
      icon: CheckCircle,
      title: "Quality Management",
      image: "/images/quality-control.jpg",
      description:
        "We deliver world-class quality management services that maintain the highest standards across all operations, ensuring product integrity and operational excellence.",
      features: [
        {
          icon: CheckCircle,
          title: "Quality Inspections",
          description: "Comprehensive inspection protocols ensuring products meet specifications.",
        },
        {
          icon: TrendingUp,
          title: "Process Optimization",
          description: "Continuous improvement initiatives to enhance quality and efficiency.",
        },
        {
          icon: ClipboardCheck,
          title: "Documentation & Reporting",
          description: "Detailed quality reports and compliance documentation.",
        },
      ],
    },
    {
      id: "program",
      icon: Users,
      title: "Program Management",
      image: "/images/program-management.jpg",
      description:
        "Strategic oversight and coordination of complex government and commercial programs worldwide, ensuring successful execution and stakeholder satisfaction.",
      features: [
        {
          icon: Users,
          title: "Strategic Planning",
          description: "Comprehensive program planning and stakeholder coordination.",
        },
        {
          icon: TrendingUp,
          title: "Performance Tracking",
          description: "Real-time monitoring and reporting of program milestones and KPIs.",
        },
        {
          icon: Shield,
          title: "Risk Management",
          description: "Proactive risk identification and mitigation strategies.",
        },
      ],
    },
    {
      id: "logistics",
      icon: Globe,
      title: "Global Logistics",
      image: "/images/warehouse.jpg",
      description:
        "Comprehensive logistics support and coordination for international operations, providing seamless movement of goods and materials across global supply chains.",
      features: [
        {
          icon: MapPin,
          title: "Global Coordination",
          description: "Worldwide logistics coordination and support services.",
        },
        {
          icon: Package,
          title: "Inventory Management",
          description: "Efficient inventory tracking and warehouse management solutions.",
        },
        {
          icon: Globe,
          title: "Transportation Management",
          description: "Optimized transportation planning and execution across all modes.",
        },
      ],
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">Our Services</h1>
          <p className="text-xl md:text-2xl max-w-3xl mx-auto">
            Comprehensive solutions for global supply chain management,
            compliance, and operational excellence
          </p>
        </div>
      </section>

      {/* Services Detail Sections */}
      {serviceDetails.map((service, index) => {
        const Icon = service.icon;
        const isEven = index % 2 === 0;

        return (
          <section
            key={service.id}
            id={service.id}
            className={`py-20 ${isEven ? "bg-white" : "bg-gray-50"}`}
          >
            <div className="container mx-auto px-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                {/* Image */}
                <div className={isEven ? "order-1" : "order-1 lg:order-2"}>
                  <img
                    src={service.image}
                    alt={service.title}
                    className="rounded-lg shadow-xl w-full h-[400px] object-cover"
                  />
                </div>

                {/* Content */}
                <div className={isEven ? "order-2" : "order-2 lg:order-1"}>
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h2 className="text-4xl font-bold text-gray-900">
                      {service.title}
                    </h2>
                  </div>

                  <p className="text-lg text-gray-600 mb-8">
                    {service.description}
                  </p>

                  <div className="space-y-4">
                    {service.features.map((feature, idx) => {
                      const FeatureIcon = feature.icon;
                      return (
                        <Card key={idx} className="border-l-4 border-l-blue-600">
                          <CardHeader className="pb-3">
                            <div className="flex items-center gap-3">
                              <FeatureIcon className="w-5 h-5 text-blue-600" />
                              <CardTitle className="text-lg">
                                {feature.title}
                              </CardTitle>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <CardDescription className="text-base">
                              {feature.description}
                            </CardDescription>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </section>
        );
      })}

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Need a Custom Solution?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            We tailor our services to meet your specific operational needs and
            compliance requirements.
          </p>
          <a
            href="/contact"
            className="inline-block bg-white text-blue-600 hover:bg-gray-100 font-semibold text-lg px-8 py-4 rounded-lg transition-colors"
          >
            Contact Our Team
          </a>
        </div>
      </section>

      <Footer />
    </div>
  );
}
