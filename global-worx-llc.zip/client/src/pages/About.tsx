import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Target, Eye, Award, Globe, Shield, Users } from "lucide-react";

export default function About() {
  const values = [
    {
      icon: Shield,
      title: "Integrity",
      description:
        "We operate with unwavering honesty and transparency in all our dealings, maintaining the highest ethical standards.",
    },
    {
      icon: Award,
      title: "Excellence",
      description:
        "We are committed to delivering exceptional quality and precision in every aspect of our services.",
    },
    {
      icon: Users,
      title: "Collaboration",
      description:
        "We work closely with our clients and partners to achieve shared goals and mutual success.",
    },
    {
      icon: Globe,
      title: "Global Perspective",
      description:
        "We bring international expertise and understanding to every project, regardless of location.",
    },
  ];

  const capabilities = [
    "Government Contract Compliance",
    "International Trade Regulations",
    "Quality Assurance Standards",
    "Supply Chain Security",
    "Risk Assessment & Mitigation",
    "Program Performance Management",
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">About Us</h1>
          <p className="text-xl md:text-2xl max-w-3xl mx-auto">
            Delivering clarity and reliability where it matters most in global
            operations
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-4xl font-bold text-gray-900">Our Mission</h2>
              </div>
              <p className="text-lg text-gray-600 mb-6">
                Global Worx LLC is dedicated to protecting the integrity of
                critical supply chains and government programs worldwide through
                trusted observation, rigorous compliance verification, and
                strategic management services.
              </p>
              <p className="text-lg text-gray-600">
                We serve as the eyes and hands of our clients in the field,
                providing reliable oversight and actionable intelligence that
                enables confident decision-making in complex global operations.
              </p>
            </div>
            <div>
              <img
                src="/images/team-meeting.jpg"
                alt="Team collaboration"
                className="rounded-lg shadow-xl w-full h-[400px] object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <img
                src="/images/warehouse.jpg"
                alt="Global operations"
                className="rounded-lg shadow-xl w-full h-[400px] object-cover"
              />
            </div>
            <div className="order-1 lg:order-2">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Eye className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-4xl font-bold text-gray-900">Our Vision</h2>
              </div>
              <p className="text-lg text-gray-600 mb-6">
                To be the world's most trusted partner in global supply chain
                assurance and compliance, setting the standard for precision,
                reliability, and integrity in international operations.
              </p>
              <p className="text-lg text-gray-600">
                We envision a future where every critical supply chain operates
                with complete transparency and accountability, supported by our
                unwavering commitment to excellence and innovation.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Our Core Values
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <Card
                  key={index}
                  className="text-center hover:shadow-xl transition-shadow duration-300"
                >
                  <CardHeader>
                    <div className="w-14 h-14 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    <CardTitle className="text-xl">{value.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">{value.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Capabilities Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Our Expertise
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Deep knowledge across critical operational domains
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {capabilities.map((capability, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 bg-white p-4 rounded-lg shadow-sm"
                >
                  <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0" />
                  <span className="text-lg text-gray-700">{capability}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Partner With Us
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Experience the difference that precision, integrity, and global
            expertise can make in your operations.
          </p>
          <a
            href="/contact"
            className="inline-block bg-white text-blue-600 hover:bg-gray-100 font-semibold text-lg px-8 py-4 rounded-lg transition-colors"
          >
            Get in Touch
          </a>
        </div>
      </section>

      <Footer />
    </div>
  );
}
